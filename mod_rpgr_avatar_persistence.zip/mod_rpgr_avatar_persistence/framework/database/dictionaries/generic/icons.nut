::AP.Database.Generic.Icons <-
{
	ActionPoints = "ui/icons/action_points.png",
	Ammo = "ui/icons/asset_ammo.png",
	ArmorParts = "ui/icons/asset_supplies.png",
	Bravery = "ui/icons/bravery.png",
	Brother = "ui/icons/asset_brothers.png",
	FatigueRecoveryRate = "ui/icons/fatigue.png",
	Hitpoints = "ui/icons/health.png",
	Initiative = "ui/icons/initiative.png",
	Locked = "ui/icons/icon_locked.png",
	Medicine = "ui/icons/asset_medicine.png",
	MeleeDefense = "ui/icons/melee_defense.png",
	MeleeSkill = "ui/icons/melee_skill.png",
	Momentum = "skills/ap_momentum_effect.png",
	Money = "ui/icons/asset_money.png",
	RangedDefense = "ui/icons/ranged_defense.png",
	RangedSkill = "ui/icons/ranged_skill.png",
	Skull = "ui/icons/chance_to_hit_head.png",
	Special = "ui/icons/perks.png",
	Stamina = "ui/icons/fatigue.png",
	Time = "ui/icons/action_points.png",
	Warning = "ui/icons/warning.png"
};